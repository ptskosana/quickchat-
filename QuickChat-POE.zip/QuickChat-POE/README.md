# QuickChat POE

A Java console application for user registration/login and message management.

## Included source files

- `Login.java` – registration and login validation.
- `Message.java` – message creation, validation, IDs, hashes and JSON formatting.
- `MessageManager.java` – sent, stored and disregarded message collections, searching, deletion, reporting and JSON persistence.
- `Main.java` – console application entry point and menus.

## Requirements

- JDK 17 or later
- NetBeans or another Java IDE
- Maven (for opening/building this Maven project)

## Run in NetBeans

1. Extract the ZIP file.
2. In NetBeans, choose **File > Open Project** and select the extracted `QuickChat-POE` folder.
3. Wait for Maven project loading to finish.
4. Run `quickchat.Main`.

The program creates `stored_messages.json` in its working directory when stored messages are saved.

## Important submission note

This project has been assembled from the source code available in the conversation. Compare it with the official PROG5121 POE brief and marking rubric before submitting. In particular, confirm whether the lecturer requires Java arrays rather than `List` collections, exact menu wording, specific test classes, screenshots, or additional documentation. Do not claim that the project meets requirements that have not been checked against the brief.
